# BeautyFlux × Elfiko — Ultra HD Studio

Web photo enhancer yang siap di-upload ke **GitHub Pages, Vercel, Netlify**, atau dijalankan langsung dari folder.

## Fitur yang sudah bekerja
- Ultra HD: upscale 2× default + sharpening
- HD Enhance
- BeautyFlux: skin smoothing + glow
- AI Enhance (local auto-enhance; bukan API/cloud AI)
- Brightness, contrast, saturation
- Sharpness
- Skin Smooth
- Glow
- Filter: Original, Cinema, Warm, Cool, Mono, Vivid
- Rotate kiri/kanan
- Flip horizontal/vertical
- Compare sebelum/sesudah
- Zoom
- Export JPG / PNG / WEBP
- Scale 1× / 1.5× / 2× / 3×
- Quality 60–100
- Copy image ke clipboard (browser yang mendukung)
- Drag & drop / file picker
- No API key
- Foto diproses lokal di browser; tidak di-upload ke server

## Jalankan di Termux
```bash
pkg update -y
pkg install python -y
cd ~/beautyflux-elfiko-ultra-hd
python -m http.server 8080
```
Lalu buka:
`http://127.0.0.1:8080`

## Upload ke GitHub
1. Buat repository baru.
2. Upload semua isi folder ini.
3. Pastikan `index.html` berada di root repository.

## Deploy Vercel
- Import repository GitHub ke Vercel.
- Framework: Other / static.
- Build command: kosong.
- Output directory: `.`

`vercel.json` sudah disertakan.

## Catatan
Semua enhancement adalah pemrosesan Canvas lokal. Fitur yang benar-benar membutuhkan model AI/cloud (misalnya face restoration berbasis neural network) tidak diklaim sebagai AI cloud di project ini.


## V2 — fitur tambahan
- Denoise
- Clarity
- Vivid+
- Soft Portrait
- Dramatic
- Matte
- Noir
- Sepia
- Invert
- Vignette
- Pixelate
- Blur
- Undo / Redo sampai 20 langkah
- Tetap satu file foto saja di `assets/background.jpg`

Tidak ada file foto 5 MB. Ukuran project ditentukan oleh kode/fitur; background dibuat ringan supaya halaman tetap cepat.


### Offline LUT Library
Includes 240 real 17×17×17 RGB color LUT presets locally in `assets/color-luts.json`; the selector applies the chosen color transform in-browser without an API.
