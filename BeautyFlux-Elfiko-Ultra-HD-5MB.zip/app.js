const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={img:null,fileName:"photo",brightness:0,contrast:0,saturation:0,sharpness:0,smooth:0,glow:0,filter:"none",scale:2,format:"image/jpeg",quality:.95,rot:0,flipH:1,flipV:1,zoom:1,preset:"ultra"};
const canvas=$("#canvas"), ctx=canvas.getContext("2d",{willReadFrequently:true}), compare=$("#compareCanvas"), cctx=compare.getContext("2d");
const fileInput=$("#fileInput"), stage=$("#stage");

function setStatus(t){$("#status").textContent=t}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function readFile(file){if(!file||!file.type.startsWith("image/"))return;
  const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{state.img=im;state.fileName=file.name.replace(/\.[^.]+$/,"");$("#imageName").textContent=file.name;$("#resolution").textContent=`${im.naturalWidth} × ${im.naturalHeight}`;$(".empty").style.display="none";canvas.classList.add("visible");applyPreset("ultra");render();};im.src=r.result};r.readAsDataURL(file)}
fileInput.onchange=e=>readFile(e.target.files[0]);
$("#dropZone").addEventListener("dragover",e=>{e.preventDefault()});
$("#dropZone").addEventListener("drop",e=>{e.preventDefault();readFile(e.dataTransfer.files[0])});

function applyPreset(p){
 state.preset=p;
 const vals={ultra:[10,18,16,72,18,12],hd:[6,14,10,52,8,7],beauty:[7,12,12,34,58,35],ai:[8,20,18,65,30,20]};
 const v=vals[p]||vals.ultra;
 ["brightness","contrast","saturation","sharpness","smooth","glow"].forEach((k,i)=>{state[k]=v[i];$("#"+k).value=v[i];$("#"+k+"Out").textContent=v[i]});
 $$(".tool").forEach(x=>x.classList.toggle("active",x.dataset.preset===p)); setStatus(p==="ai"?"AI local optimize":"Preset applied"); render();
}
$$(".tool").forEach(b=>b.onclick=()=>applyPreset(b.dataset.preset));

["brightness","contrast","saturation","sharpness","smooth","glow"].forEach(k=>$("#"+k).oninput=e=>{state[k]=+e.target.value;$("#"+k+"Out").textContent=e.target.value;render()});
$$("[data-filter]").forEach(b=>b.onclick=()=>{state.filter=b.dataset.filter;$$("[data-filter]").forEach(x=>x.classList.toggle("selected",x===b));render()});
$$("[data-format]").forEach(b=>b.onclick=()=>{state.format=b.dataset.format;$$("[data-format]").forEach(x=>x.classList.toggle("selected",x===b))});
$("#scale").onchange=e=>{state.scale=+e.target.value;render()};
$("#quality").oninput=e=>{state.quality=+e.target.value/100;$("#qualityOut").textContent=e.target.value};
$("#rotateL").onclick=()=>{state.rot=(state.rot+3)%4;render()};
$("#rotateR").onclick=()=>{state.rot=(state.rot+1)%4;render()};
$("#flipH").onclick=()=>{state.flipH*=-1;render()};
$("#flipV").onclick=()=>{state.flipV*=-1;render()};
$("#resetBtn").onclick=()=>{state.rot=0;state.flipH=1;state.flipV=1;state.filter="none";applyPreset("ultra")};
$("#zoomIn").onclick=()=>{state.zoom=clamp(state.zoom+.1,.5,2);$("#zoomLabel").textContent=Math.round(state.zoom*100)+"%";render()};
$("#zoomOut").onclick=()=>{state.zoom=clamp(state.zoom-.1,.5,2);$("#zoomLabel").textContent=Math.round(state.zoom*100)+"%";render()};

function drawBase(target,context,scale){
 if(!state.img)return;
 const sw=state.img.naturalWidth,sh=state.img.naturalHeight,turn=state.rot%2;
 target.width=Math.round((turn?sh:sw)*scale);target.height=Math.round((turn?sw:sh)*scale);
 context.save();context.clearRect(0,0,target.width,target.height);context.translate(target.width/2,target.height/2);context.rotate(state.rot*Math.PI/2);context.scale(state.flipH*scale,state.flipV*scale);
 context.drawImage(state.img,-sw/2,-sh/2,sw,sh);context.restore();
}
function pixels(){
 const w=canvas.width,h=canvas.height;let d=ctx.getImageData(0,0,w,h),a=d.data;
 const br=state.brightness*2.55, ct=(state.contrast+100)/100, sat=(state.saturation+100)/100;
 for(let i=0;i<a.length;i+=4){let r=a[i]+br,g=a[i+1]+br,b=a[i+2]+br;const y=.299*r+.587*g+.114*b;r=y+(r-y)*sat;g=y+(g-y)*sat;b=y+(b-y)*sat;
   if(state.filter==="warm"){r*=1.08;g*=1.025;b*=.94}else if(state.filter==="cool"){r*=.94;g*=1.01;b*=1.09}else if(state.filter==="mono"){const m=.299*r+.587*g+.114*b;r=g=b=m}else if(state.filter==="cinema"){r*=1.05;g*=.99;b*=.96}else if(state.filter==="vivid"){r*=1.10;g*=1.08;b*=1.08}
   r=(r-128)*ct+128;g=(g-128)*ct+128;b=(b-128)*ct+128;a[i]=clamp(r,0,255);a[i+1]=clamp(g,0,255);a[i+2]=clamp(b,0,255);
 }ctx.putImageData(d,0,0);
}
function sharpen(amount){
 if(!amount)return;
 const w=canvas.width,h=canvas.height,src=ctx.getImageData(0,0,w,h),s=src.data,out=new Uint8ClampedArray(s);
 const k=amount/100*.8;
 for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const p=(y*w+x)*4;for(let c=0;c<3;c++){const v=s[p+c]* (1+4*k)-k*(s[p-4+c]+s[p+4+c]+s[p-w*4+c]+s[p+w*4+c]);out[p+c]=clamp(v,0,255)}}
 src.data.set(out);ctx.putImageData(src,0,0);
}
function beauty(){
 if(!state.smooth&&!state.glow)return;
 const w=canvas.width,h=canvas.height,d=ctx.getImageData(0,0,w,h),a=d.data;
 const rad=Math.max(1,Math.round(1+state.smooth/24));
 if(state.smooth){
   const copy=new Uint8ClampedArray(a);
   for(let y=rad;y<h-rad;y+=2) for(let x=rad;x<w-rad;x+=2){
     const p=(y*w+x)*4,r=a[p],g=a[p+1],b=a[p+2],lum=(r+g+b)/3;
     if(lum>55&&lum<235){
       let sr=0,sg=0,sb=0,n=0;
       for(let yy=-rad;yy<=rad;yy++) for(let xx=-rad;xx<=rad;xx++){
         const q=((y+yy)*w+x+xx)*4;sr+=copy[q];sg+=copy[q+1];sb+=copy[q+2];n++;
       }
       const mix=state.smooth/130;a[p]=r*(1-mix)+(sr/n)*mix;a[p+1]=g*(1-mix)+(sg/n)*mix;a[p+2]=b*(1-mix)+(sb/n)*mix;
     }
   }
   ctx.putImageData(d,0,0);
 }
 if(state.glow){
   ctx.save();ctx.globalAlpha=state.glow/500;ctx.filter=`blur(${Math.max(1,state.glow/20)}px)`;
   const tmp=document.createElement('canvas');tmp.width=w;tmp.height=h;tmp.getContext('2d').drawImage(canvas,0,0);ctx.drawImage(tmp,0,0);ctx.restore();
 }
}
function render(){
 if(!state.img)return;
 setStatus("Rendering…");
 drawBase(canvas,ctx,state.scale);
 pixels(); beauty(); sharpen(state.sharpness);
 $("#resolution").textContent=`${canvas.width} × ${canvas.height}`;
 requestAnimationFrame(()=>setStatus("Ready • HD applied"));
}
function exportCanvas(){
 if(!state.img){alert("Pilih foto dulu.");return null}
 render(); const type=state.format, q=state.quality;
 return canvas.toDataURL(type,q);
}
$("#saveBtn").onclick=()=>{const url=exportCanvas();if(!url)return;const ext=state.format==="image/png"?"png":state.format==="image/webp"?"webp":"jpg";const a=document.createElement("a");a.href=url;a.download=`${state.fileName}-beautyflux-${state.preset}.${ext}`;a.click()};
$("#downloadBtn").onclick=()=>$("#saveBtn").click();
$("#copyBtn").onclick=async()=>{try{render();const blob=await new Promise(r=>canvas.toBlob(r,"image/png"));await navigator.clipboard.write([new ClipboardItem({"image/png":blob})]);setStatus("Gambar dicopy ke clipboard")}catch(e){setStatus("Clipboard tidak didukung browser")}};
$("#compareBtn").onclick=()=>{if(!state.img)return;compare.width=canvas.width;compare.height=canvas.height;cctx.clearRect(0,0,compare.width,compare.height);cctx.drawImage(state.img,0,0,compare.width,compare.height);stage.classList.toggle("compareOn");$("#compareBtn").textContent=stage.classList.contains("compareOn")?"◐ Show HD":"◐ Compare"};
stage.addEventListener("dblclick",()=>$("#compareBtn").click());


state.fx=new Set(); state.history=[]; state.future=[];
function snapshot(){return JSON.stringify({brightness:state.brightness,contrast:state.contrast,saturation:state.saturation,sharpness:state.sharpness,smooth:state.smooth,glow:state.glow,filter:state.filter,scale:state.scale,rot:state.rot,flipH:state.flipH,flipV:state.flipV,fx:[...state.fx]})}
function restore(s){const o=JSON.parse(s);Object.assign(state,o);state.fx=new Set(o.fx||[]);["brightness","contrast","saturation","sharpness","smooth","glow"].forEach(k=>{if($("#"+k)){ $("#"+k).value=state[k]; $("#"+k+"Out").textContent=state[k]}});render()}
function pushHistory(){state.history.push(snapshot());if(state.history.length>20)state.history.shift();state.future=[]}
$$("[data-fx]").forEach(b=>b.onclick=()=>{pushHistory();const f=b.dataset.fx;if(state.fx.has(f))state.fx.delete(f);else state.fx.add(f);b.classList.toggle("active",state.fx.has(f));render()});
$("#undoBtn").onclick=()=>{if(!state.history.length)return;state.future.push(snapshot());restore(state.history.pop())};
$("#redoBtn").onclick=()=>{if(!state.future.length)return;state.history.push(snapshot());restore(state.future.pop())};

function advancedPixels(){
 if(!state.img)return;
 let d=ctx.getImageData(0,0,canvas.width,canvas.height), a=d.data, w=canvas.width,h=canvas.height;
 const fx=state.fx;
 if(fx.has("denoise")||fx.has("soft")){
   const src=new Uint8ClampedArray(a), radius=fx.has("denoise")?1:2;
   for(let y=radius;y<h-radius;y++)for(let x=radius;x<w-radius;x++){let p=(y*w+x)*4,sr=0,sg=0,sb=0,n=0;
     for(let yy=-radius;yy<=radius;yy++)for(let xx=-radius;xx<=radius;xx++){let q=((y+yy)*w+x+xx)*4;sr+=src[q];sg+=src[q+1];sb+=src[q+2];n++}
     const mix=fx.has("soft")?.16:.28;a[p]=a[p]*(1-mix)+(sr/n)*mix;a[p+1]=a[p+1]*(1-mix)+(sg/n)*mix;a[p+2]=a[p+2]*(1-mix)+(sb/n)*mix;
   }
 }
 for(let i=0;i<a.length;i+=4){
   let r=a[i],g=a[i+1],b=a[i+2];
   if(fx.has("clarity")){r=(r-128)*1.14+128;g=(g-128)*1.14+128;b=(b-128)*1.14+128}
   if(fx.has("dramatic")){r=(r-120)*1.22+120;g=(g-120)*1.18+120;b=(b-120)*1.16+120}
   if(fx.has("matte")){r=r*.9+20;g=g*.9+20;b=b*.9+20}
   if(fx.has("sepia")){let nr=.393*r+.769*g+.189*b,ng=.349*r+.686*g+.168*b,nb=.272*r+.534*g+.131*b;r=nr;g=ng;b=nb}
   if(fx.has("noir")){let m=.299*r+.587*g+.114*b;r=g=b=m}
   if(fx.has("invert")){r=255-r;g=255-g;b=255-b}
   if(fx.has("vivid")){let m=(r+g+b)/3;r=m+(r-m)*1.3;g=m+(g-m)*1.3;b=m+(b-m)*1.3}
   a[i]=clamp(r,0,255);a[i+1]=clamp(g,0,255);a[i+2]=clamp(b,0,255)
 }
 ctx.putImageData(d,0,0);
 if(fx.has("vignette")){
   const g=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.72);
   g.addColorStop(0,"rgba(0,0,0,0)");g.addColorStop(1,"rgba(0,0,0,.62)");
   ctx.save();ctx.fillStyle=g;ctx.fillRect(0,0,w,h);ctx.restore();
 }
 if(fx.has("blur")){const tmp=document.createElement("canvas");tmp.width=w;tmp.height=h;tmp.getContext("2d").drawImage(canvas,0,0);ctx.save();ctx.filter="blur(2px)";ctx.drawImage(tmp,0,0);ctx.restore()}
 if(fx.has("pixel")){
   const size=Math.max(4,Math.round(Math.min(w,h)/160));const tmp=document.createElement("canvas");tmp.width=Math.ceil(w/size);tmp.height=Math.ceil(h/size);const t=tmp.getContext("2d");t.imageSmoothingEnabled=false;t.drawImage(canvas,0,0,tmp.width,tmp.height);ctx.save();ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,w,h);ctx.drawImage(tmp,0,0,tmp.width,tmp.height,0,0,w,h);ctx.restore()
 }
}
const oldRender=render;
render=function(){if(!state.img)return;oldRender();advancedPixels();setStatus("Ready • "+(state.preset==="ultra"?"Ultra HD":"Enhance")+" + local effects")};

state.lut=null;
fetch("assets/color-luts.json").then(r=>r.json()).then(pack=>{
 const sel=$("#lutSelect"); pack.presets.forEach(p=>{const o=document.createElement("option");o.value=p.id;o.textContent=p.name;sel.appendChild(o)});
 window.__LUTS=pack.presets;
}).catch(()=>{});
$("#lutSelect").onchange=e=>{state.lut=(window.__LUTS||[]).find(x=>x.id===e.target.value)||null;render()};
const __renderBeforeLUT=render;
render=function(){
 __renderBeforeLUT();
 if(!state.img||!state.lut)return;
 const lut=state.lut.rgb,w=canvas.width,h=canvas.height,d=ctx.getImageData(0,0,w,h),a=d.data;
 for(let i=0;i<a.length;i+=4){
   const r=Math.round(a[i]/255*16),g=Math.round(a[i+1]/255*16),b=Math.round(a[i+2]/255*16);
   const idx=((b*17*17)+(g*17)+r)*3;
   a[i]=lut[idx];a[i+1]=lut[idx+1];a[i+2]=lut[idx+2];
 }
 ctx.putImageData(d,0,0);
};
